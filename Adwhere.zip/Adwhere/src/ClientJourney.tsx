import React, { ChangeEvent, FormEvent, useState } from 'react';

const AdCampaignPage: React.FC = () => {
  

  return (
    <div className="ad-campaign-page">

    </div>
  );
};

export default AdCampaignPage;